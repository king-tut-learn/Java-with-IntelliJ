import java.util.Random;

public class Array {

    public static  void main (String [] args)
    {
        int[] dice = new int [6];
        Random rand = new Random();

        for(int i = 0; i < dice.length; i++)
        {
            dice[i] = i + 1;
        }


        System.out.println("Dice #: " + dice[rand.nextInt(6)]);
    }
}
