package tut;

import java.util.Scanner;


public class And_Or_Not {

    public static void main(String [] args)
    {
       int x,y;
       x = 9;
       y = 0;

       //condition with the and logic
       if (x == 2 && y ==3)
       {
           System.out.println("X = 3 and Y = 2");
       }

       //condition with or logic
       else if (x==2 || y ==3)
       {
           System.out.println("X = 3 or Y = 2");
       }

       //condition with the not logic
       else if (x != 2)
       {
           System.out.println("X is not equal to 2");
       }

       else
       {
           System.out.println("False");
       }
    }
}
