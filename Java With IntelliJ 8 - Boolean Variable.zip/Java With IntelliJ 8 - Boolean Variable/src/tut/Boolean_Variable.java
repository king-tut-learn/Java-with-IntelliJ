package tut;

import java.util.Scanner;


public class Boolean_Variable {

    public static void main(String [] args)
    {
      //Boolean Variable
      //A boolean variable is a variable that stores
      //true and false
      //Very useful in gamedev and other application
      //How to declare a boolean variable and assign it?
        boolean var = false;
        System.out.println(var);

      //Practical Application
        System.out.println("2 + 2 = ");
        Scanner input = new Scanner(System.in);
        String answer = input.nextLine();
        boolean iscorrect = true;
        if (answer.equals("4"))
        {
            iscorrect = true;
        }
        else
        {
            iscorrect = false;
        }

        if (!iscorrect)
        {
            System.out.println("Sorry! This is the wrong answer!!");

        }
        else
        {
            System.out.println("Correct! Congrats!!");
        }
    }
}
