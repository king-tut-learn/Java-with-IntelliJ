package tut;

import java.util.Scanner;


public class Switch_Case {

    public static void main(String [] args)
    {
        System.out.println("What's your favorite icecream?");
        Scanner input = new Scanner(System.in);
        String favorite_Icecream = input.nextLine();

        switch (favorite_Icecream)
        {
            case "chocolate":
                System.out.println("You Like Chocolate Ice Cream!!");
                break;
            case "vanilla":
                System.out.println("You Like Vanilla Ice Cream!!");
                break;
            case "strawberry":
                System.out.println("You Like Strawberry Ice Cream!!");
                break;
            default:
                System.out.println("You Like Other Flavor Of Ice Cream!!");
        }

    }
}
