import java.util.Scanner;

public class Do_While_Loop {
    public static void main(String[] args) {

            //Do While Loop Implementation

      /*  Scanner input = new Scanner(System.in);
        System.out.println("2 + 2 = ");
        int right_answer = input.nextInt();

            do {
                if (right_answer != 4)
                {
                    System.out.println("Wrong answer! Try again!!");
                    right_answer = input.nextInt();
                }


            }while(right_answer != 4);

            System.out.println("Correct!!");*/
       int x = 2;

        while (x > 3)
        {
            System.out.println("x > 3");
        }


        do {

            System.out.println("x > 3");

        }while(x > 3);

        }
    }