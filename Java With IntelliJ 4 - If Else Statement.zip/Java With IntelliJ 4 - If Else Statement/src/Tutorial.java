import java.util.*;
public class Tutorial {
    public static void main(String [] args)
    {
        String choice;
        Scanner input = new Scanner(System.in);

        System.out.println("Where is the Sears Tower?");
        choice = input.nextLine();

        if (choice.equals("Chicago"))
        {
            System.out.println("You Are Correct!!");
        }

        else
        {
            System.out.println("You Are Wrong!!");
        }
    }
}
