package tut;

import java.util.Scanner;


public class For_Loop {

    public static void main(String [] args)
    {
        //For Loop
        //A kind of loop that iterates from the initial point to the final point at a
        //certain amount of steps or iteration

        //How to implement a For Loop
        for(int i = 1; i <= 9; i++)
        {
            System.out.println(i);
        }

        //Applied example
        System.out.println("Initiating Countdown!!");
        for(int i = 5; i > 0; i--)
        {
            System.out.println(i);
        }
        System.out.println("LIFTOFF!! (Starship Raptor Engine Sound)");

    }
}
