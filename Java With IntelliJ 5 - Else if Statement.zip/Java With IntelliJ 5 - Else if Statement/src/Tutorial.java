import java.util.*;
public class Tutorial {
    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Which Door Number Do You Want to Pick? (Door 1, Door 2, or Door 3)");
        int doornum = input.nextInt();

        if (doornum == 1)
        {
            System.out.println("You are in the Jungle!");
        }
		//Else if statement
        else if (doornum == 2)
        {
            System.out.println("You are in the Desert!");
        }

        else if (doornum == 3)
        {
            System.out.println("You are in the City! Your ideal City!");
        }

        else
        {
            System.out.println("That's not either door number 1, 2, or 3!!");
        }

    }
}
