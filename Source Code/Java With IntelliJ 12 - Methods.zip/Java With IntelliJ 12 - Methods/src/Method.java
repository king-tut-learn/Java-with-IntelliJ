import java.util.Scanner;

public class Method {

    //implementing a method
    public static void Quiz(String Question, String Canswer) {
        //Methods

        //This Block of Code

        //declaring and input
        Scanner input = new Scanner(System.in);

        //Asking a question about planets
        System.out.println(Question);

        //putting your answer to your question
        System.out.print("Answer: ");
        String answer = input.nextLine();

        //this is used for the loop so that it loops over and over again until
        //right answer is provided
        boolean rightAnswer = false;

        //inside the loop determines if you got the right answer or not
        while (!rightAnswer) {
            if (answer.equals(Canswer)) {
                System.out.println("Correct!! Ending Program...");
                rightAnswer = true;
            } else {
                System.out.println("Wrong!! Try Again!!");
                System.out.print("Answer: ");
                answer = input.nextLine();
            }

        }

    }

    public static void main(String[] args) {
        Quiz("How many Continents on Earth?", "7");

    }
}