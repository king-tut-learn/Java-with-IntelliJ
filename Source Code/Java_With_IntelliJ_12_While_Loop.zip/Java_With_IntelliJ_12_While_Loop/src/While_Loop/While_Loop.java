package While_Loop;
import java.util.Scanner;

import java.util.Scanner;
//For Loop - Going from A to B by means of increments/decrements
//While Loop - If condition is true run the code over and over until condition is false

public class While_Loop {

    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        int y = 0;
        //implementing while loop
        while(y < 9)
        {
            System.out.println("King Tut is looping!!");
            System.out.print("Enter a Value: ");
            y = input.nextInt();
        }

    }

}
