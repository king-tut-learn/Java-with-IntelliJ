public class Tutorial {

    public static void main(String [] args)
    {
        //int, long, double, float, char, String
        int x = 2;
        long y = 3;
        double z = 1.5;
        float a = (float) 2.6;
        char letter = 'q';
        String word = "King Tut bla bla bla!!";


        System.out.println(word + "Tutorial bla blaalba");
    }

}
